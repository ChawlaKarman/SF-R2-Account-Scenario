({
	fetchDependentPicklist : function(component,event,helper) {
        var action=component.get("c.getDependentPicklist");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                component.set("v.DependentPicklistMap", result);
                var countryMap=component.get("v.DependentPicklistMap");
                var lis=[];
        		for(var key in countryMap){
            		lis.push(key);
        		}
                component.set("v.countryList",lis);
                }
                else{                    
                    console.log("Failed at querrying Picklist");
                }
        });
        $A.enqueueAction(action);
	}
})