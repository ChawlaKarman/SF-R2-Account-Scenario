({
	doInit : function(component, event, helper) {
		helper.fetchDependentPicklist(component, event, helper);
	},
    countryChange : function(component, event, helper) {
        var selectedValue= component.get("v.selectedCountry");
        if(selectedValue!='')
            component.set("v.disableState",false);
        else
            component.set("v.disableState",true);
        var lis=component.get("v.DependentPicklistMap")[selectedValue];
        component.set("v.stateList",lis);
	},
    handleStateChange : function(component, event, helper){
        if(component.get("v.selectedState")!=""){
            var country=component.get("v.selectedCountry");
            var state=component.get("v.selectedState");
            var appEvent=$A.get("e.c:AcountFilterEvent");
            appEvent.setParams({
                "country":country,
                "state":state
            });
            appEvent.fire();
        }
    }
})