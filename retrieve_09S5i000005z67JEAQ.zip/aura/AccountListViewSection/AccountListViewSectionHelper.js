({
	onInit : function (component,event,helper) {
        let inputWrapper={};
        inputWrapper.fields=component.get("v.fieldApiName");
        var action=component.get("c.getDatatableWrapper");
        console.log('inputWrapper'+inputWrapper.fields);
        action.setParams({
            inputWrapper:inputWrapper
        });
        action.setCallback(this, function(response){
            if(response.getState()==="SUCCESS"){
                let columns=response.getReturnValue().fieldsMetadata.map(obj=>{return {label:obj.label, fieldName: obj.apiName, type: obj.fieldType}; });
                component.set("v.columns",columns);
                console.log('columns'+columns);
            }
            else{                    
                console.log("Failed to querry columns");
            }
        });
        $A.enqueueAction(action);
    }
})