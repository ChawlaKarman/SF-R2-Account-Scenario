({
	doInit : function(component, event, helper) {
        helper.onInit(component,event,helper);
	},
    handleApplicationEvent : function(component,event,helper) {
        var country = event.getParam("country");
        var state = event.getParam("state");
        component.set("v.searchValue","");
        
        var fieldsList=component.get("v.fieldApiName").split(",");
        var action=component.get("c.fetchAccountRecords");
        action.setParams({
            country:country,
            state:state,
            fieldsList:fieldsList
        });
        action.setCallback(this, function(response){
            if(response.getState()==="SUCCESS"){
                component.set("v.data",response.getReturnValue());
                component.set("v.dataCopy",response.getReturnValue());
                console.log('Records fetched successfully');
            }
            else{
                console.log('Failed to querry Account records');
            }
        });
        $A.enqueueAction(action);
    },
    handleChange: function(component, event, helper) {
        var searchKey=component.get("v.searchValue");
        if(searchKey!="")
        {
            var filteredData=[];
            var data=component.get("v.dataCopy");
            var searchKey=component.get("v.searchValue");
            let i=0;
            for (i=0;i<data.length;i++){
                console.log(data[i]);
                var strData=JSON.stringify(data[i]);
                if(strData.toLowerCase().includes(searchKey.toLowerCase()))
                    filteredData.push(data[i]);
            }
            component.set("v.data",filteredData);
        }
        else
        {
            var orignalData=component.get("v.dataCopy");
            component.set("v.data",orignalData);
        }
    }

})